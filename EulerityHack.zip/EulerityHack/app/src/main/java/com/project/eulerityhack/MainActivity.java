package com.project.eulerityhack;


import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("", "in here");

        tv = (TextView) findViewById(R.id.images);
        final Button buttonEulerity = (Button) findViewById(R.id.button1);
       // final ImageView iv = (ImageView) findViewById(R.id.imageView);


        buttonEulerity.setOnClickListener(onClick1);

    }

    //global on click listener
    private View.OnClickListener onClick1 = new View.OnClickListener() {
        @Override
        //on click events
        public void onClick(View v) {

           // tv.setText("in here");
            Log.d("in here", "in click");
            String[] sUrl = {"http://google.com"};
            Log.d("the url is", " " +sUrl);
            new GetContentUrlTask(tv, "GET", "");

        }

    };


}

