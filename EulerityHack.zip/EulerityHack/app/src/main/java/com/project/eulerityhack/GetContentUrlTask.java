package com.project.eulerityhack;
        import android.os.AsyncTask;
        import android.util.Log;
        import android.widget.ImageView;
        import android.widget.TextView;

        import java.net.*;
        import java.io.*;

public class GetContentUrlTask extends AsyncTask<String, Integer, String> {
    private TextView tv;
    private ImageView iv;
    private String method;
    private String paramList;


    public GetContentUrlTask(TextView tv, String method, String paramList) {

        Log.d("in get content url", " ");
        this.method = method;
        this.paramList = paramList;

    }


    public String doInBackground(String... urls) {

        Log.d("in do in backG", " ");

        String url = urls[0];

        try {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            // optional default is GET
            con.setRequestMethod(this.method);
            String urlParameters = this.paramList;
            if (this.method.equalsIgnoreCase("POST"))
            {
                String USER_AGENT = "Mozilla/5.0";
                con.setRequestProperty("User-Agent", USER_AGENT);
                con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

                con.setDoOutput(true);
                DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                wr.writeBytes(urlParameters);
                wr.flush();
                wr.close();

                int responseCode = con.getResponseCode();
                System.out.println("\nSending 'POST' request to URL : " + url);
                System.out.println("Post parameters : " + urlParameters);
                System.out.println("Response Code : " + responseCode);

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                return response.toString();

            }
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));

            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString();


        }catch(Exception e) {
            e.printStackTrace();
            return "Error in http Request";
        }
    }


    protected void onProgressUpdate(Integer... progress) {
    }

    protected void onPostExecute(String result) {
        tv.setText(result); //set results to textview so I know get request is working

        //get result (array of images)
        result = result.replace("\"", "");
        String outString = "";

        //declaration of array to hold image results
        String[] picArr = result.split("url:");
        for (int i = 1; i < picArr.length;i++) {
            String picURL = picArr[i].split(",")[0];
            Log.d("url of image",picURL);
        }


    }
}

//where I left off: code should be working for getting the json array of images and logging each url, however when I run the app it skips
//code frames so, causing the app to not function properly - the reason for this skipping is "the application may
//  be doing too much work on its main thread" , next I would have created a new class called ImageLoader to load the images of
//the array asynchronously
